from django.shortcuts import HttpResponse, redirect

def index(request):
	return HttpResponse("placeholder to later display list of all blogs")

def new(request):
	return HttpResponse("placeholder to display a new form to create a new blog")

def create(request):
	return redirect("/")

def show(request, number):
	return HttpResponse(f"placeholder to display blog number: {number}")

def edit(request, number):
	return HttpResponse(f"placeholder to edit blog {number}")

def destroy(request, number):
	return redirect("/")

# def helloCats(request):
# 	return HttpResponse("This one's for the cats...")

# def helloPerson(request, name):
# 	return HttpResponse("Hello " + name)

# def catch_all(request, url):
# 	return redirect("/helloCats")

# def krustyKrab(request):
# 	context = {
# 		"menu_items": ["Krabby Patty", "Kelp Fries", "Chum", "Pizza"]
# 	}
# 	return render(request, "Spongebob.html", context) #serves us in html files. To note dictionary does not need to be named context, can be anything just make sure it matches

##more practice for assignment##
